<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Email</title>
</head>
<body>
    <p>{!! $content !!}</p>
</body>
</html>
