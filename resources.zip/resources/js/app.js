import './bootstrap';
import Admin from './Admin';
import User from './User';

// Đưa class ra window để dùng trong balde
window.Admin = Admin;
window.User = User;